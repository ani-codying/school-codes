module org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.desktop;

    opens org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication to javafx.fxml;
    exports org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication;
    exports org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers;
    opens org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers to javafx.fxml;
    exports org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;
    opens org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers to javafx.fxml;
}