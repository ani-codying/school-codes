package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class RPWidth {
    public TextField volume;
    public TextField length;
    public TextField height;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        double v = Integer.parseInt(volume.getText());
        double l = Integer.parseInt(length.getText());
        double h = Integer.parseInt(height.getText());

        //double solve = (l*w*h)/3;
        double w = (3*v)/(l*h);

        volumeAns.setText(String.valueOf(w));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "rectangular-prism.fxml");
    }
}
