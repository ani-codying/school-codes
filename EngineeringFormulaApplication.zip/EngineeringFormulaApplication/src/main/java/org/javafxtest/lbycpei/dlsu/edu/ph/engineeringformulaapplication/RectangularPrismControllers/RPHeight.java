package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class RPHeight {
    public TextField volume;
    public TextField length;
    public TextField width;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        double v = Integer.parseInt(volume.getText());
        double l = Integer.parseInt(length.getText());
        double w = Integer.parseInt(width.getText());

        //double solve = (l*w*h)/3;
        double h = (3*v)/(l*w);

        volumeAns.setText(String.valueOf(h));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "rectangular-prism.fxml");
    }
}
