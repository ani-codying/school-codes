package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class RPController {
    public String URL = "rectangularPrism/";

    @FXML
    public void volume(ActionEvent event) throws IOException {
        MainController.load(event, URL + "rp-volume.fxml");
    }

    @FXML
    public void length(ActionEvent event) throws IOException {
        MainController.load(event, URL + "rp-length.fxml");
    }

    @FXML
    public void width(ActionEvent event) throws IOException {
        MainController.load(event, URL + "rp-width.fxml");
    }

    @FXML
    public void height(ActionEvent event) throws IOException {
        MainController.load(event, URL + "rp-height.fxml");
    }

    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "main-menu.fxml");
    }
}
