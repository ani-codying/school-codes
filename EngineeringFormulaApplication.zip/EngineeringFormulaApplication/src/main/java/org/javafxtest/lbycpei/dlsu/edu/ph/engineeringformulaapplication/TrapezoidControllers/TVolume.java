package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers;

import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class TVolume {
    public TextField height;
    public TextField length;
    public TextField baseA;
    public TextField baseB;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        System.out.println("Trapezoid Solved!!");
        double a = Integer.parseInt(baseA.getText());
        double b = Integer.parseInt(baseB.getText());
        double l = Integer.parseInt(length.getText());
        double h = Integer.parseInt(height.getText());

        double solve = ((a + b) * l * h)/2;

        volumeAns.setText(String.valueOf(solve));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "trapezoid.fxml");
    }
}
