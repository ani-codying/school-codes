package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class TrapezoidController {
    public String URL = "trapezoid/";

    @FXML
    public void volume(ActionEvent event) throws IOException {
        System.out.println("Trapezoid Volume");
        MainController.load(event, URL + "trapezoid-volume.fxml");
    }

    @FXML
    public void height(ActionEvent event) throws IOException {
        System.out.println("Trapezoid Height");
        MainController.load(event, URL + "trapezoid-height.fxml");
    }

    @FXML
    public void length(ActionEvent event) throws IOException {
        System.out.println("Trapezoid Height");
        MainController.load(event, URL + "trapezoid-length.fxml");
    }

    @FXML
    public void baseA(ActionEvent event) throws IOException {
        System.out.println("Trapezoid Base A");
        MainController.load(event, URL + "trapezoid-basea.fxml");
    }

    @FXML
    public void baseB(ActionEvent event) throws IOException {
        System.out.println("Trapezoid Base B");
        MainController.load(event, URL + "trapezoid-baseb.fxml");
    }

    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "main-menu.fxml");
    }
}
