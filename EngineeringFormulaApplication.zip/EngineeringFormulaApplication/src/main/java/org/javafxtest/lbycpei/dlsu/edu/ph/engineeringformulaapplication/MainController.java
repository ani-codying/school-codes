package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication;

import javafx.application.Platform;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {
    // Load FXML file
    public static void load(ActionEvent event, String file) throws IOException {
        /*URL url = getClass().getResource("/org/javafxtest/lbycpei/dlsu/edu/ph/engingeeringformulaapplication/trapezoid.fxml");
        System.out.println("URL: " + url);*/
        /* It kept making an error saying my resource was 'null',
        turns out the problem was within the 'target' folder because trapezoid was in a different place*/
        String url = "/org/javafxtest/lbycpei/dlsu/edu/ph/engineeringformulaapplication/";

        Parent root = FXMLLoader.load(MainController.class.getResource(url + file));
        Scene scene = new Scene(root);

        // Get current stage
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene(scene);
        stage.show();
    }

    // Trapezoid
    @FXML
    private void trapezoid(ActionEvent event) throws IOException {
        /* ORIGINALLY HERE
        System.out.println("trapezoid");
        String url = "/org/javafxtest/lbycpei/dlsu/edu/ph/engingeeringformulaapplication/";

        Parent trapezoidRoot = FXMLLoader.load(MainController.class.getResource(url + "trapezoid.fxml"));
        Scene trapezoidScene = new Scene(trapezoidRoot);

        // Get current stage
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();

        stage.setScene(trapezoidScene);
        stage.show();*/

        System.out.println("Trapezoid");
        load(event, "trapezoid.fxml");
    }

    @FXML
    public void rectangularPyramid(ActionEvent event) throws IOException{
        load(event, "rectangular-prism.fxml");
    }

    @FXML
    public void button3() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ALERT !!");
        alert.setHeaderText("Please standby :(");
        alert.setContentText("This was discontinued shortly after its suggestion, " +
                "we would like to apologize on behalf of the developer's decisions to making an alert instead.");
        alert.showAndWait();
    }

    @FXML
    public void exit(ActionEvent event) {
        System.out.println("Bye bye!");
        Platform.exit();
    }

    //add another thing?
}