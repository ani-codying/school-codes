package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class RPVolume {
    public TextField length;
    public TextField width;
    public TextField height;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        double l = Integer.parseInt(length.getText());
        double w = Integer.parseInt(width.getText());
        double h = Integer.parseInt(height.getText());

        double solve = (l*w*h)/3;

        volumeAns.setText(String.valueOf(solve));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "rectangular-prism.fxml");
    }
}
