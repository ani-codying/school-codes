package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("ENGINEERING CALCULATOR APPLICATION");
        stage.setScene(scene);
        stage.show();

        // minimum window sizing
        stage.setMinWidth(620);
        stage.setMinHeight(420);

        // style sheet
        scene.getStylesheets().add(Objects.requireNonNull(MainApp.class.getResource("mystyles.css")).toExternalForm());
    }

    public static void main(String[] args) {
        launch();
    }
}