package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class TBaseA {
    public TextField volume;
    public TextField height;
    public TextField length;
    public TextField baseB;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        System.out.println("Base A solved! If J is for Java, A is for Amusement, V is for VM options, A again is for AAAA-");
        double b = Integer.parseInt(baseB.getText());
        double l = Integer.parseInt(length.getText());
        double h = Integer.parseInt(height.getText());
        double v = Integer.parseInt(volume.getText());

        //double solve = ((a + b) * l * h)/2;
        double a = (2*v)/(l*h) - b;

        volumeAns.setText(String.valueOf(a));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "trapezoid.fxml");
    }
}
