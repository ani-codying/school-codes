package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.TrapezoidControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class TLength {
    public TextField volume;
    public TextField height;
    public TextField baseA;
    public TextField baseB;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        System.out.println("Length solved! Only God knows why I'm going thru such Lengths");
        double a = Integer.parseInt(baseA.getText());
        double b = Integer.parseInt(baseB.getText());
        double h = Integer.parseInt(height.getText());
        double v = Integer.parseInt(volume.getText());

        //double solve = ((a + b) * l * h)/2;
        double l = ( 2*v ) / ( a + b ) * h;

        volumeAns.setText(String.valueOf(l));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "trapezoid.fxml");
    }
}
