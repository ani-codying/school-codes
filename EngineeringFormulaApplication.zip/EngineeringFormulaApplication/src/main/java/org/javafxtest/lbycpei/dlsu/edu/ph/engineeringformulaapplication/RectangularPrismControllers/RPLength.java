package org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.RectangularPrismControllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.javafxtest.lbycpei.dlsu.edu.ph.engineeringformulaapplication.MainController;

import java.io.IOException;

public class RPLength {
    public TextField volume;
    public TextField width;
    public TextField height;
    public TextArea volumeAns;

    //solve button
    @FXML
    public void solve() throws IOException {
        double v = Integer.parseInt(volume.getText());
        double w = Integer.parseInt(width.getText());
        double h = Integer.parseInt(height.getText());

        //double solve = (l*w*h)/3;
        double l = (3*v)/(w*h);

        volumeAns.setText(String.valueOf(l));
    }

    // back button
    @FXML
    public void back(ActionEvent event) throws IOException {
        MainController.load(event, "rectangular-prism.fxml");
    }
}
